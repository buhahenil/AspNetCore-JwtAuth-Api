﻿namespace User_Auth.DTOs.Auth
{
    public class AuthResponse
    {
        public string Token { get; set; } = null!;
        public DateTime Expires { get; set; }
        public string UserName { get; set; } = null!;
    }
}
