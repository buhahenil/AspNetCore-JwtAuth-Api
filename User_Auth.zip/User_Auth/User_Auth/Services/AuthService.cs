﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using User_Auth.Data;
using User_Auth.DTOs.Auth;
using User_Auth.Entities;
using User_Auth.Helpers;
using User_Auth.Interfaces;

namespace User_Auth.Services
{
    public class AuthService : IAuthService
    {
        private readonly ApplicationDbContext _db;
        private readonly JwtSettings _jwt;
        private readonly IPasswordHasher<User> _passwordHasher;

        public AuthService(ApplicationDbContext db, IOptions<JwtSettings> jwtOptions, IPasswordHasher<User> passwordHasher)
        {
            _db = db;
            _jwt = jwtOptions.Value;
            _passwordHasher = passwordHasher;
        }

        public async Task<AuthResponse?> RegisterAsync(RegisterRequest request)
        {
            // check exists
            if (await _db.Users.AnyAsync(u => u.UserName == request.UserName || u.Email == request.Email))
                return null;

            var user = new User
            {
                UserName = request.UserName,
                Email = request.Email
            };

            user.PasswordHash = _passwordHasher.HashPassword(user, request.Password);
            _db.Users.Add(user);
            await _db.SaveChangesAsync();

            return GenerateAuthResponse(user);
        }

        public async Task<AuthResponse?> LoginAsync(LoginRequest request)
        {
            var user = await _db.Users
                .FirstOrDefaultAsync(u => u.UserName == request.UserNameOrEmail || u.Email == request.UserNameOrEmail);

            if (user == null)
                return null;

            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, request.Password);
            if (result == PasswordVerificationResult.Failed)
                return null;

            return GenerateAuthResponse(user);
        }

        private AuthResponse GenerateAuthResponse(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwt.Key);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Email, user.Email)
            };

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(_jwt.ExpiresMinutes),
                Issuer = _jwt.Issuer,
                Audience = _jwt.Audience,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwt = tokenHandler.WriteToken(token);

            return new AuthResponse
            {
                Token = jwt,
                Expires = tokenDescriptor.Expires!.Value.ToUniversalTime(),
                UserName = user.UserName
            };
        }

    }
}
