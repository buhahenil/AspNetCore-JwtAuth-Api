﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User_Auth.Entities
{
    public class User
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required, MaxLength(100)]
        public string UserName { get; set; } = null!;

        [Required, MaxLength(200)]
        public string Email { get; set; } = null!;

        // store hashed password
        [Required]
        public string PasswordHash { get; set; } = null!;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
