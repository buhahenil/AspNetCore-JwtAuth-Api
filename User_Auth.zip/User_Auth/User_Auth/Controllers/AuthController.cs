﻿using Microsoft.AspNetCore.Mvc;
using User_Auth.DTOs.Auth;
using User_Auth.Interfaces;

namespace User_Auth.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _auth;

        public AuthController(IAuthService auth) => _auth = auth;

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            var res = await _auth.RegisterAsync(request);
            if (res == null) return BadRequest(new { message = "User already exists or invalid data" });
            return Ok(res);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var res = await _auth.LoginAsync(request);
            if (res == null) return Unauthorized();

            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = true,        // true in production
                SameSite = SameSiteMode.Strict,
                Expires = res.Expires.ToUniversalTime()
            };

            Response.Cookies.Append("X-Access-Token", res.Token, cookieOptions);

            return Ok(new { message = "Logged in", expires = res.Expires, user = res.UserName });
        }


    }
}
